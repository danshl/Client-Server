#pragma once

#include "../include/ConnectionHandler.h"

// TODO: implement the STOMP protocol
class StompClient
{
private:

public:
    int return_unique_id();
};
